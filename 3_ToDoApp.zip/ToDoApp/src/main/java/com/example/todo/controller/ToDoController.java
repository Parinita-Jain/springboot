package com.example.todo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ToDoController {
	
	@Value("${spring.application.name}")
	private String appName;
	
	@Value("${myname}")
	private String name;
	
	@Value("${lecture:java}")
	private String lecture;
	
	@Value("${timing:10am}")
	private String timing;
	
	@RequestMapping("/")
	public String home() {
		System.out.println("reaching home page");
		//assuming home is actually the name of some html file
		return "home.html";
	}
	
	@RequestMapping("/about")
	@ResponseBody
	public String aboutus() {
		String data = "";
		data += name + " is teaching " + lecture + " at " + timing;
		data += " project created: " + appName;
		return data;
	}
	
	@RequestMapping("/name")
	@ResponseBody
	public List<String> getData(){
		List<String> name = new ArrayList<>();
		name.add("harry");
		name.add("mike");
		name.add("scott");
		name.add("smith");
		return name;
	}
}
