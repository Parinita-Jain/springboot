package com.example.todo.service;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.todo.model.ToDo;
import com.example.todo.repository.ToDoRepository;

@Service
public class ToDoService {
//	private ToDo task = null;
	
	Map<Integer, ToDo> toDoMap;
	AtomicInteger atomic;
	
	@Autowired
	private ToDoRepository toDoRepository;
	
	public ToDoService() {
		toDoMap = new HashMap<>();
		atomic = new AtomicInteger();
		
		ToDo task1 = new ToDo();
		task1.setTaskID(atomic.incrementAndGet());
		task1.setTaskName("Learning Java");
		task1.setStatus("Completed");
		toDoMap.put(task1.getTaskID(), task1);
		
		ToDo task2 = new ToDo();
		task2.setTaskID(atomic.incrementAndGet());
		task2.setTaskName("Dancing");
		task2.setStatus("InProgress");
		toDoMap.put(task2.getTaskID(), task2);
	}
	
	public Iterable<ToDo> getAllTask(){
		return toDoRepository.findAll();
	}
	
	public void addTask(ToDo newTask) {
//		newTask.setTaskID(atomic.incrementAndGet());
//		toDoMap.put(newTask.getTaskID(), newTask);
		toDoRepository.save(newTask);
	}
	
	public void deleteTask(Integer id) {
//		toDoMap.remove(id);
		toDoRepository.deleteById(id);
	}
	
	public ToDo getTaskById(Integer id) {
		return toDoRepository.findById(id).get();
	}
	
	public void updateTask(ToDo todo) {
		toDoRepository.save(todo);
	}
	
//	public ToDoService() {
//		task = new ToDo();
//		task.setTaskID(2);
//		task.setTaskName("learning java");
//		task.setStatus("completed");
//	}
	
//	public ToDo getTask() {
//		return task;
//	}
}
