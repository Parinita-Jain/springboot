package com.example.di;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

//Inversion of control
@Component
@Scope(value = "prototype")
public class Student {
	public Student() {
		System.out.println("Student Object Created");
	}
	
	private Integer id;
	private String name;
	private Float marks;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Float getMarks() {
		return marks;
	}
	public void setMarks(Float marks) {
		this.marks = marks;
	}
	
}
