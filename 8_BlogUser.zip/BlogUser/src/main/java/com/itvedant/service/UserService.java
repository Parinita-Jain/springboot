package com.itvedant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itvedant.model.User;
import com.itvedant.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;
	
	public Iterable<User> getAll(){
		return userRepository.findAll();
	}
	
	public User add(User user) {
		return userRepository.save(user);
	}
	
	public void delete(Integer id) {
		userRepository.deleteById(id);
	}
	
	public User find(Integer id) {
		return userRepository.findById(id).get();
	}
	
	public User update(Integer id, User user) {
		user.setId(id);
		return userRepository.save(user);
	}
}
