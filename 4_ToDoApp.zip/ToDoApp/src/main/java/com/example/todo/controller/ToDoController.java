package com.example.todo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.todo.model.ToDo;
import com.example.todo.service.ToDoService;

@Controller
public class ToDoController {
	
	@Value("${spring.application.name}")
	private String appName;
	
	@Value("${myname}")
	private String name;
	
	@Value("${lecture:java}")
	private String lecture;
	
	@Value("${timing:10am}")
	private String timing;
	
	@Autowired
	private ToDoService toDoService;
	
	@RequestMapping("/")
	public String home(Model model) {
		//System.out.println("reaching home page");
		//assuming home is actually the name of some html file
		
		//to add the dynamic content in the view we need to first add the 
		//content in the model object using addAttribute method
		model.addAttribute("name","harry");
		model.addAttribute("day","sunday");
		model.addAttribute("age",23);
			
		ToDo task = toDoService.getTask();
		
		model.addAttribute("task",task);
		
		return "home.html";
	}
	
	@RequestMapping("/about")
	@ResponseBody
	public String aboutus() {
		String data = "";
		data += name + " is teaching " + lecture + " at " + timing;
		data += " project created: " + appName;
		return data;
	}
	
	@RequestMapping("/name")
	@ResponseBody
	public List<String> getData(){
		List<String> name = new ArrayList<>();
		name.add("harry");
		name.add("mike");
		name.add("scott");
		name.add("smith");
		return name;
	}
}
