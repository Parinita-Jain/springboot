package com.example.todo.service;

import org.springframework.stereotype.Service;

import com.example.todo.model.ToDo;

@Service
public class ToDoService {
	private ToDo task = null;
	
	public ToDoService() {
		task = new ToDo();
		task.setTaskID(2);
		task.setTaskName("learning java");
		task.setStatus("completed");
	}
	
	public ToDo getTask() {
		return task;
	}
}
