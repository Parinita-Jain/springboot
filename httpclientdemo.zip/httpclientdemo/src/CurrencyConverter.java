import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Scanner;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class CurrencyConverter {
    public static void main(String[] args) throws Exception{
        System.out.println("Welcome to Currency Converter");
        System.out.println("Select the currency code of the currency to be converted into INR: ");

        String[] currencyCode = {"USD","EUR","GBP","JPY","KRW","CNY"};

        for(int i = 0; i <currencyCode.length; i++){
            System.out.println(i+1 + ". " + currencyCode[i]);
        }

        System.out.print("Enter your choice: ");
        Scanner sc = new Scanner(System.in);
        int choice = sc.nextInt();

        if(choice >= 1 && choice <= 6){

            System.out.print("Enter the amount of this currency that you have: ");
            float amount = sc.nextFloat();

            String url = "https://v6.exchangerate-api.com/v6/a64dec9a4f8f3ac3c6286020/latest/" 
                                + currencyCode[choice-1];

            HttpRequest request = HttpRequest.newBuilder()
                                            .GET()
                                            .uri(URI.create(url))
                                            .build();

            HttpClient client = HttpClient.newBuilder().build();

            HttpResponse<String> response = client.send(request, 
                                HttpResponse.BodyHandlers.ofString());

            // System.out.println(response.body());
            JSONParser parser = new JSONParser();

            JSONObject obj = (JSONObject)parser.parse(response.body());
            JSONObject conversionRate = (JSONObject)obj.get("conversion_rates");
            System.out.println("Amount in " + currencyCode[choice-1] + ": " + amount);
            System.out.println("Converted Amount in INR: " + amount * (double)conversionRate.get("INR"));
        }
        else{
            System.out.println("Retry.... Wrong Choice Selected!!!");
        }
    }
}
