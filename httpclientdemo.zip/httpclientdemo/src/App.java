/*HttpClient API ==> provide some classes and method to send a request
    to the URL and get back the response
    1. HttpRequest => Will create the request object and which we will
                        mention the URL to which request is to be sent
    2. HttpClient => Will send the request to the URL and get the 
                        response from that URL
    3. HttpResponse => Is the response that will be recieve by HttpClient
                        object
*/

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class App {
    public static void main(String[] args) throws Exception {
        String url = "https://cat-fact.herokuapp.com/facts/";

        HttpRequest request = HttpRequest.newBuilder()
                                         .GET()
                                         .uri(URI.create(url))
                                         .build();

        HttpClient client = HttpClient.newBuilder().build();

        HttpResponse<String> response = client.send(request, 
                            HttpResponse.BodyHandlers.ofString());

        // System.out.println(response.body());

        JSONParser parser = new JSONParser();
        JSONArray factArray = (JSONArray)parser.parse(response.body());

        for(Object fact : factArray){
            System.out.println("Status: " + ((JSONObject)fact).get("status"));
            System.out.println("Fact: " + ((JSONObject)fact).get("text"));
        }
    }
}
