package com.example.todo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

class Student{
	private int id;
	private String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}

@Controller
public class ToDoController {
	@RequestMapping("/")	
	@ResponseBody
	public String home() {
		return "welcome";
	}
	
	@RequestMapping("/student")
	@ResponseBody
	public Student getStudent() {
		Student s = new Student();
		s.setId(1);
		s.setName("mike");
		return s;
	}
}
