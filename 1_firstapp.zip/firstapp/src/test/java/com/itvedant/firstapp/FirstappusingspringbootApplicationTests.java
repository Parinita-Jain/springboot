package com.itvedant.firstapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstappusingspringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
