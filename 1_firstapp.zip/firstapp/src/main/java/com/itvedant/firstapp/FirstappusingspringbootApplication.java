package com.itvedant.firstapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstappusingspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstappusingspringbootApplication.class, args);
	}

}
