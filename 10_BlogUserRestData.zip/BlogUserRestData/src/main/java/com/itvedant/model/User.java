package com.itvedant.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import lombok.Data;

@Entity
@Data
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Integer id;
	@Column(nullable = false)
	String name;
	@Column(nullable = false, unique = true)
	String email;
	@Column(nullable = false)
	String password;
	@OneToOne
	@JoinColumn(name = "address_id")
	Address address;
}
