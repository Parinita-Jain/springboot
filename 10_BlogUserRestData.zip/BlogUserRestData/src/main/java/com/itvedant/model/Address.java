package com.itvedant.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.Data;

@Entity
@Data
public class Address {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Integer id;
	@Column(nullable = false)
	String city;
	@Column(nullable = false)
	String state;
	@Column(nullable = false)
	String zipCode;
	
	@OneToOne(mappedBy = "address")
	User user;
}
