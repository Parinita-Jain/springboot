package com.itvedant.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.itvedant.model.CreateUserRequest;
import com.itvedant.service.UserService;

@RestController
public class UserController {
	@Autowired
	private UserService userService;
	
	@PostMapping("/auth/register")
	public ResponseEntity<?> register(@RequestBody CreateUserRequest userRequest){
		this.userService.register(userRequest);
		return new ResponseEntity<>("User registered successfully",HttpStatus.OK);
	}
}
