package com.itvedant.service;

import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.itvedant.model.User;
import com.itvedant.repository.UserRepository;

@Service
public class CustomUserDetailsService
	implements UserDetailsService{
	
	@Autowired
	private UserRepository userRepository;

	@Override
	@Transactional
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		return this.userRepository
				.findByEmail(username)
				.map(user -> {
					System.out.println("here");
					return new User(							
							user.getEmail(),
							user.getPassword(),
							user.getRoles().stream()
								.map(role -> new SimpleGrantedAuthority(role))
								.collect(Collectors.toList())
					);
				}).orElseThrow(() -> {
					throw new UsernameNotFoundException("User with email does not exists.");
				});
	}
}
