package com.itvedant.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;

import com.itvedant.model.User;

@Repository
public interface UserRepository extends 
	CrudRepository<User, Integer>{
	
	@RestResource(exported = false)
	<S extends User> S save(S entity);
	
	@RestResource(exported = false)
	Optional<User> findByEmail(String email);
}
