package com.itvedant.petstoreapp.entities;

import java.time.Instant;
import java.util.List;

import org.hibernate.validator.constraints.Length;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Entity
//@Table(name = "tblProduct")
@EntityListeners(AuditingEntityListener.class)
public class Product {
    @Id
    //we are telling the database to auto generate
    //the unique id values
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @NotNull
    @Length(min = 3, max = 20, message = "product name should have 3 - 20 characters")
    private String name;
    @NotNull
    @Min(value = 0)
    @Max(value = 4000)
    private Double price;
    private String description;

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private Instant createdAt;
    @LastModifiedDate
    private Instant updatedAt;

    //One product belongs one category
    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category category;

    //In the case of manytomany relationship, we will create
    //a separate table in which we will create
    //two joincolumns
    //one for product table referring id of the product
    //second for orders table referring id of the orders
    @ManyToMany
    @JoinTable(name = "product_orders",
               joinColumns = @JoinColumn(name="product_id", referencedColumnName = "id"),
               inverseJoinColumns = @JoinColumn(name="orders_id", referencedColumnName = "id"))
    private List<Orders> orders;

    //In this field we will save the download URL for the image
    private String imageUrl;
}
