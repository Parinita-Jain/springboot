package com.itvedant.petstoreapp.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.itvedant.petstoreapp.entities.Product;

import jakarta.annotation.security.RolesAllowed;

@CrossOrigin(origins = "*")
public interface ProductRepository 
    extends JpaRepository<Product, Integer>{
    //https://docs.spring.io/spring-data/jpa/reference/jpa/query-methods.html
    //where name = name
    @PreAuthorize("hasRole('HR')")
    Product findByName(String name);

    //where price > value
    //http://localhost:8080/products/search/findByPriceGreaterThan?value=300
    @RolesAllowed("IT")
    List<Product> findByPriceGreaterThan(double value);
    //where price < value

    @Secured("ROLE_HR")
    List<Product> findByPriceLessThan(double value);
    //where price between low and high
    //http://localhost:8080/products/search/findByPriceBetween?low=100&high=300
    List<Product> findByPriceBetween(double low, double high);
}
