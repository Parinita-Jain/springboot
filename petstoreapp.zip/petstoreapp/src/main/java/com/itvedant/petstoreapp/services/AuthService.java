package com.itvedant.petstoreapp.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.itvedant.petstoreapp.entities.User;
import com.itvedant.petstoreapp.repositories.UserRepository;

@Service
public class AuthService {
    @Autowired
    private UserRepository repository;

    @Autowired
    private BCryptPasswordEncoder encoder;

    public String register(User user){
        //first we get the original password
        String originalPassword = user.getPassword();
        //then we convert it into the encoded format
        String encodedPassword = encoder.encode(originalPassword);
        //now we will set this encoded password for the user
        user.setPassword(encodedPassword);
        //register/save the user object in the database
        repository.save(user);
        return "User Registered Successfully";
    }
}
