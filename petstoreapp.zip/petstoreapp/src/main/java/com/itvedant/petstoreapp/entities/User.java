package com.itvedant.petstoreapp.entities;

import java.time.Instant;
import java.util.Collection;
import java.util.List;

import org.hibernate.validator.constraints.Length;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.itvedant.petstoreapp.validators.Phone;
import com.itvedant.petstoreapp.validators.VerifyPassword;

import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Entity
@EntityListeners(AuditingEntityListener.class)
// @VerifyPassword(field1= "password", field2 = "confirmPassword")
public class User implements UserDetails{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @NotNull(message = "first name cannot be null")
    @NotBlank(message = "first name cannot be blank")
    private String firstName;

    @NotNull(message = "last name cannot be null")
    @Length(min = 3, max = 10, message = "last name should have 3 - 10 characters")
    private String lastName;

    //Username and Password are most important field for the login process
    //authentication process
    @NotNull(message = "email cannot be null")
    @Email
    @Column(unique = true)
    private String email; //this will be our username

    @NotNull(message = "phone cannot be null")
    @Phone
    private String phone;

    private String password; //this password has to encoded and then saved in the database

    //One user can belong to multiple roles
    //harry => HR, ADMIN
    //Here since the field is of collection types
    //In database it has to be mapped in a separate table, with id of the user
    //as the foreign key
    //This field will be used for authorization process
    @ElementCollection
    private List<String> roles;

    @Transient
    //@Transient will make sure the column
    //of this field is not created in the table
    private String confirmPassword;

    @CreatedDate
    @Column(updatable = false)
    private Instant createdAt;
    @LastModifiedDate
    private Instant updatedAt;

    //one user can have only one address
    //here in the user table created for this User entity
    //we want to add foreign key column to refer the id 
    //of the address, use @JoinColumn annotation
    @OneToOne
    @JoinColumn(name = "addr_id")
    private Address addr;

    @Transient
    private Collection<? extends GrantedAuthority> authorities;

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return this.authorities;    
    }

    @Override
    public String getUsername() {
        return this.email;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}
