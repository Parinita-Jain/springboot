package com.itvedant.petstoreapp.services;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.itvedant.petstoreapp.FileStorageProperties;
import com.itvedant.petstoreapp.entities.Product;
import com.itvedant.petstoreapp.repositories.ProductRepository;

@Service
public class FileService {
    //This variable will contain the path of the folder
    //where the files has to be uploaded and downloaded
    private final Path rootLocation;

    //This is constructor based injection
    public FileService(FileStorageProperties properties){
        //Here we are initializing the value for the rootLocation
        this.rootLocation = Paths.get(properties.getUploadDir());
    }

    @Autowired
    private ProductRepository repository;

    public String fileUpload(Integer id, MultipartFile file){
        //First we are checking if the product with id provided exists in the
        //database or not because we will do uploading only for existing products
        Product foundProduct = this.repository.findById(id).orElse(null);
        try{            
            if(foundProduct == null)
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, 
                                                "Product with ID does not exists");
            else{
                //File which is coming along with the request we will read that file
                //using InputStream
                //and then write the file in the uploads folder
                //basically we copy the request file and paste it in the uploads folder

                //This statement is specifying what should be the name of the file in the
                //uploads folder. It should be same as that of the request file
                Path destinationFile = this.rootLocation.resolve(file.getOriginalFilename());

                //setting the inputstream to read the file coming in the request
                InputStream inputStream = file.getInputStream();

                //now we will copy the file and write in the destination location
                Files.copy(inputStream, destinationFile, StandardCopyOption.REPLACE_EXISTING);
                
                //ServletUriComponentsBuilder.fromCurrentContextPath() ==>
                //will give http://localhost:8080
                String imageUrl = ServletUriComponentsBuilder.fromCurrentContextPath()
                                        .path("/products/download/")
                                        .path(file.getOriginalFilename())
                                        .toUriString();

                //we will update imageUrl for the product
                foundProduct.setImageUrl(imageUrl);
                //saving in the database
                this.repository.save(foundProduct);
                
                return "File Uploaded Successfully";
            }
        }
        catch(Exception e){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                            "Server facing some issue in uploading the file");
        }
    }

    //import org.springframework.core.io.Resource;
    public Resource fileDownload(String fileName){
        Path filePath = rootLocation.resolve(fileName);

        try{
            Resource downloadedFile = new UrlResource(filePath.toUri());

            return downloadedFile;
        }
        catch(Exception e){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, 
                                                "File Cannot be Downloaded");
        }
    }
}
