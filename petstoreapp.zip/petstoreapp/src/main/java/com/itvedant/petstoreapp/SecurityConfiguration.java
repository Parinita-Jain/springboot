package com.itvedant.petstoreapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

import com.itvedant.petstoreapp.services.MyUserDetailsService;

@Configuration
@EnableMethodSecurity(
    prePostEnabled = true,
    jsr250Enabled = true,
    securedEnabled = true
)
public class SecurityConfiguration {
    @Bean
    public SecurityFilterChain configure(HttpSecurity http) throws Exception{
        http.csrf().disable()
            .authorizeHttpRequests()
            //here all the HTTP request methods are allowed
            //.requestMatchers("/products/**")
            .requestMatchers("/register")
            .permitAll()
            .requestMatchers(HttpMethod.GET, "/products/**")
            .permitAll()
            .requestMatchers(HttpMethod.POST, "/products/**")
            .permitAll()
            .requestMatchers("/users/**")
            .hasRole("HR")
            .requestMatchers("/orders")
            .hasRole("IT")
            .anyRequest()
            .authenticated()
            .and()
            .httpBasic()
            .and()
            .authenticationProvider(this.daoAuthenticationProvider());

        return http.build();
    }

    //For authentication, we will save the password in the encoded format while registering the user
    //This is will also be needed to encode the incoming password of the user
    @Bean
    public BCryptPasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }

    //UserDetailsService => interface that is used by the Authentication Provider
    //to retrieve the UserDetails object based on the username that the user has
    //used to login

    //UserDetails => interface which contains the information about the user like
    //username, password, roles, etc which will be returned to the UserDetailsService
    //so that the user can be authenticated and authorized

    @Autowired
    private MyUserDetailsService service;

    @Bean
    public DaoAuthenticationProvider daoAuthenticationProvider(){
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setPasswordEncoder(this.passwordEncoder());
        provider.setUserDetailsService(service);
        return provider;
    }

    @Bean
    public UserDetailsService registerUsers(){
        UserDetails user1 = User.withUsername("harry")
                                .password(passwordEncoder().encode("1234"))
                                .roles("HR")
                                .build();

        UserDetails user2 = User.withUsername("mike")
                                .password(passwordEncoder().encode("1234"))
                                .roles("HR")
                                .build();

        UserDetails user3 = User.withUsername("scott")
                                .password(passwordEncoder().encode("1234"))
                                .roles("IT")
                                .build();

        UserDetails user4 = User.withUsername("dan")
                                .password(passwordEncoder().encode("1234"))
                                .roles("IT")
                                .build();

        //InMemoryUserDetailsManager implements UserDetailsService and is used to store
        //user details in the memory. But this is used only when we have small number of users
        //interacting with the application. If there are more users then we will implement
        //authentication using Database
        return new InMemoryUserDetailsManager(user1, user2, user3, user4);
    }
}
