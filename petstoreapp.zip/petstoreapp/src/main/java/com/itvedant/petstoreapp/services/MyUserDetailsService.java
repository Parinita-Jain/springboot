package com.itvedant.petstoreapp.services;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.itvedant.petstoreapp.entities.User;
import com.itvedant.petstoreapp.repositories.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class MyUserDetailsService implements UserDetailsService{

    @Autowired
    private UserRepository repository;

    @Override
    @Transactional
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User findUser = repository.findByEmail(username);
        if(findUser == null){
            throw new UsernameNotFoundException("Username does not exists");
        }
        else{
            Collection<GrantedAuthority> authorities = new ArrayList<>();
            for(String role: findUser.getRoles()){
                authorities.add(new SimpleGrantedAuthority(role));
            }

            User user = new User();
            user.setAuthorities(authorities);
            user.setEmail(findUser.getEmail());
            user.setPassword(findUser.getPassword());
            return user; //sent this user to authentication provider
        }
    }
    
}
