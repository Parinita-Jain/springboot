package com.itvedant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogUserRestDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
