package com.itvedant.model;

import org.springframework.data.rest.core.config.Projection;

@Projection(name = "userWithAddress" , types = {User.class})
public interface UserWithAddress {
	Integer getId();
	String getName();
	String getEmail();
	Address getAddress();
}
