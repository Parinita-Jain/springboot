package com.itvedant.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.rest.core.config.Projection;

@Projection(name="noPassword",types = {User.class})
public interface UserWithoutPassword {
	@Value("#{target.id}")
	Integer getUserId();
	@Value("#{target.name}")
	String getUserName();
	String getEmail();
}
