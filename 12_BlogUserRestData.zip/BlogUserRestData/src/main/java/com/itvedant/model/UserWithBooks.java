package com.itvedant.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.rest.core.config.Projection;

@Projection(name = "userWithBooks" , types = {User.class})
public interface UserWithBooks {
	Integer getId();
	String getName();
	@Value("#{target.likesBook}")
	List<Book> getBooks();
}
