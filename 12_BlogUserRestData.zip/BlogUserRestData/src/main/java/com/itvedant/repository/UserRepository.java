package com.itvedant.repository;

import java.util.List;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;

import com.itvedant.model.User;
import com.itvedant.model.UserWithAddress;
import com.itvedant.model.UserWithBooks;
import com.itvedant.model.UserWithoutPassword;

//@Repository
@RepositoryRestResource(excerptProjection = UserWithBooks.class)
public interface UserRepository extends 
	//CrudRepository<User, Integer>{
	PagingAndSortingRepository<User, Integer>{
	
	@Cacheable
	Iterable<User> findAll();
	
	List<UserWithoutPassword> findAllProjectedBy();	
	
	List<User> findByName(String name);
	
	@RestResource(path = "emailPattern")
	List<User> findByEmailContaining(String pattern);
}
