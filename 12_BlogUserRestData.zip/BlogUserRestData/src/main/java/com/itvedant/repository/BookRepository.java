package com.itvedant.repository;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.itvedant.model.Book;

@Repository
public interface BookRepository extends
CrudRepository<Book, Integer>{
	@Cacheable(cacheNames = {"books"})
	Iterable<Book> findAll();
}
