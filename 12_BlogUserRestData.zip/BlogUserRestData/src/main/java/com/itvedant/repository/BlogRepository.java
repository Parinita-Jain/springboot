package com.itvedant.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.itvedant.model.Blog;

@Repository
public interface BlogRepository extends
	CrudRepository<Blog, Integer>{

}
