package com.itvedant;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
public class DemoController {
	@GetMapping("/try")
	public String tryCatch() {
//		try {
			int a = 10;
			int b = 0;
			int c = a/b;
			return "fine";
//		}
//		catch(ArithmeticException e) {
//			return "not fine";
//		}
	}
	
	@GetMapping("/demo")
	public String demo() throws CustomException {
		throw new CustomException("throwing exception");
	}
	
	@GetMapping("/new")
	public String newway() {
		throw new ResponseStatusException(HttpStatus.BAD_GATEWAY, "Bad Gateway");
	}
	
	@ExceptionHandler({ArithmeticException.class})
	public void handleException() {
		System.out.println("some error");
	}
}
