package com.itvedant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itvedant.model.User;
import com.itvedant.projection.UserWithoutPassword;
import com.itvedant.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;
	
//	public Iterable<User> getAll(){
//		return userRepository.findAll();
//	}
	
	public List<UserWithoutPassword> getAll(){
		return userRepository.findAllProjectedBy();
	}
	
	public User add(User user) {
		return userRepository.save(user);
	}
	
	public String delete(Integer id) {
		User foundUser = this.find(id);
		if(foundUser == null)
			return null;
		else{
			userRepository.deleteById(id);
			return "deleted";
		}
	}
	
	public User find(Integer id) {
		return userRepository.findById(id).orElse(null);
	}
	
	public UserWithoutPassword findWithPassword(Integer id) {
		return userRepository.findProjectedById(id).orElse(null);
	}
	
	public User update(Integer id, User user) {
		User foundUser = this.find(id);
		if(foundUser == null)
			return null;
		else{
			user.setId(id);
			return userRepository.save(user);
			
		}
	}

	public List<UserWithoutPassword> getByName(String name) {
		return this.userRepository.findByName(name);
	}
	
	public List<UserWithoutPassword> getByEmail(String text){
		//return this.userRepository.findByEmailContaining(text);
		return this.userRepository.findByEmailContainingOrNameContaining(text, text);
	}
}
