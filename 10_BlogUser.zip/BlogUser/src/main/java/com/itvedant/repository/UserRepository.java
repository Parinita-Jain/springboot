package com.itvedant.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.itvedant.model.User;
import com.itvedant.projection.UserWithoutPassword;

@Repository
public interface UserRepository
	extends CrudRepository<User, Integer>{
	List<UserWithoutPassword> findAllProjectedBy();
	
	Optional<UserWithoutPassword> findProjectedById(Integer id);
	
	List<UserWithoutPassword> findByName(String name);
	
	//List<UserWithoutPassword> findByEmail(String text);
	//List<UserWithoutPassword> findByEmailContaining(String text);
	List<UserWithoutPassword> findByEmailContainingOrNameContaining(String text1, String text2);
}
