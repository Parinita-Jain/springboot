package com.example.di;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class DependencyInjectionApplication
		implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(DependencyInjectionApplication.class, args);
	}

	//Dependency Injection
	@Autowired
	Student s;
	@Autowired
	@Qualifier("mike")
	Employee e;
	@Autowired
	@Qualifier("harry")
	Employee e1;
	
	@Override
	public void run(String... args) throws Exception {
		System.out.println("Spring Boot Console App");
		
		//Student s = new Student();
		
		s.setId(10);
		s.setName("abc");
		
		System.out.println(s.getId());
		System.out.println(s.getName());
		
		System.out.println(e.getName());
	}
}
