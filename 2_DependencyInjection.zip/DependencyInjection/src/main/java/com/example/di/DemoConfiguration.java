package com.example.di;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class DemoConfiguration {
	@Bean(name = "harry")
	public Employee getEmployee() {
		return new Employee("Harry");
	}
	
	@Bean(name = "sam")
	@Primary
	public Employee createEmployee1() {
		return new Employee("Sam");
	}
	
	@Bean(name = "mike")
	public Employee createEmployee2() {
		return new Employee("Mike");
	}
}
