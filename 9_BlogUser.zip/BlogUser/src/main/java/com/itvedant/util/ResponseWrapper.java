package com.itvedant.util;

import lombok.Data;

@Data
public class ResponseWrapper {
	private String subject;
	private Object body;
}
