package com.itvedant.projection;

import org.springframework.beans.factory.annotation.Value;

public interface UserWithoutPassword {
	//Integer getId();
	//String getName();
	String getEmail();
	@Value("ID: " + "#{target.id}" 
	+ " Name: " + "#{target.name}")
	String getIdName();
}
